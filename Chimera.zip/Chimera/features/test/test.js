//import request from "../../../requestV2"

/*
register("command",()=>{
  request({url: `https://api.hypixel.net/skyblock/profiles?key=321d5067-e72f-4c43-97a4-f14e0a0282df&uuid=28192360eee7412f9ba9478ae88c4fba`, json: true})
  .then((re)=>{
    ChatLib.chat(re.profiles[3].profile_id);
  })
  .catch(e => null)
}).setName("test")
*/
