/*
    fetch('https://api.hypixel.net/skyblock/profiles?key=321d5067-e72f-4c43-97a4-f14e0a0282df&uuid=28192360eee7412f9ba9478ae88c4fba')
  .then(response => response.json())
  .then(data => {
    // 在這裡處理獲取到的 JSON 資料
    console.log(data);
  })
  .catch(error => {
    // 處理錯誤
    console.error('Error:', error);
  });
*/